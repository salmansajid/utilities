﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace WebApplication2.DAL
{
    public class CommonBLL
    {
        CommonDLL obj = new CommonDLL();
        public DataTable getCategory()
        {
            return obj.getCategory();
        }
        public DataTable getDivision(int Id)
        {
            return obj.getDivision(Id);
        }

        public DataTable getType(int Id, string columntype)
        {
            return obj.getType(Id, columntype);
        }

        public DataTable getSubCategory(int Id)
        {
            return obj.getSubCategory(Id);
        }

        public DataTable getArcGroup(int Id)
        {
            return obj.getArcGroup(Id);
        }

        public DataTable getArc_subGroup(int Id, string columntype)
        {
            return obj.getArc_subGroup(Id, columntype);
        }

        public DataTable getBrand(int Id)
        {
            return obj.getBrand(Id);
        }
        public DataTable getSeason(int Id)
        {
            return obj.getSeason(Id);
        }
        public bool postData(string category, string Division, string Type, string Subcat, string Artgrp, string ArtgrpSub, string Brand, string Season, string Item_Id)
        {
            return obj.postData(category, Division, Type, Subcat, Artgrp, ArtgrpSub, Brand, Season, Item_Id);
        }

    }
}