﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication2.DAL
{
    public class CommonDLL
    {
        public DataTable getCategory()
        {

            using (DataTable table = DBhelper.ExecuteSelectCommand("Select * from [dbo].[Col_Category]", CommandType.Text))
            {
                if (table.Rows.Count > 0)
                {
                    return table;
                }
                else
                {
                    return null;
                }
            }
        }
        public DataTable getDivision(int Id)
        {

            using (DataTable table = DBhelper.ExecuteSelectCommand("select * from [dbo].[Col-Division] where id= " + Id, CommandType.Text))
            {
                if (table.Rows.Count > 0)
                {
                    return table;
                }
                else
                {
                    return null;
                }
            }
        }

        public DataTable getType(int Id,string columntype)
        {

            using (DataTable table = DBhelper.ExecuteSelectCommand("select * from [dbo].[Col_Type] where "+ columntype+" = " + Id, CommandType.Text))
            {
                if (table.Rows.Count > 0)
                {
                    return table;
                }
                else
                {
                    return null;
                }
            }
        }
        public DataTable getSubCategory(int Id)
        {

            using (DataTable table = DBhelper.ExecuteSelectCommand("select * from [dbo].[Col_Subcategory] where TypeId = " + Id, CommandType.Text))
            {
                if (table.Rows.Count > 0)
                {
                    return table;
                }
                else
                {
                    return null;
                }
            }
        }
        public DataTable getArcGroup(int Id)
        {

            using (DataTable table = DBhelper.ExecuteSelectCommand("select * from [dbo].[Col_ArticleGroup] where ColSubcatId  = " + Id, CommandType.Text))
            {
                if (table.Rows.Count > 0)
                {
                    return table;
                }
                else
                {
                    return null;
                }
            }
        }
        public DataTable getArc_subGroup(int Id, string columntype)
        {

            using (DataTable table = DBhelper.ExecuteSelectCommand("select * from  [dbo].[Col_ArticleSubGroup] where "+ columntype +" = " + Id, CommandType.Text))
            {
                if (table.Rows.Count > 0)
                {
                    return table;
                }
                else
                {
                    return null;
                }
            }
        }

        public DataTable getBrand(int Id)
        {

            using (DataTable table = DBhelper.ExecuteSelectCommand("select * from [dbo].[Col-Brand] where ArtSubGrpId = " + Id, CommandType.Text))
            {
                if (table.Rows.Count > 0)
                {
                    return table;
                }
                else
                {
                    return null;
                }
            }
        }
        public DataTable getSeason(int Id)
        {

            using (DataTable table = DBhelper.ExecuteSelectCommand("select *  from [dbo].[Col-Season] where Brand_Id = " + Id, CommandType.Text))
            {
                if (table.Rows.Count > 0)
                {
                    return table;
                }
                else
                {
                    return null;
                }
            }
        }



        public bool postData(string category, string Division, string Type, string Subcat, string Artgrp, string ArtgrpSub, string Brand, string Season, string Item_Id)
        {

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Category", category),
                new SqlParameter("@Division", Division),
                new SqlParameter("@Type", Type),
                new SqlParameter("@Subcat", Subcat),
                new SqlParameter("@Artgrp", Artgrp),
                new SqlParameter("@ArtgrpSub", ArtgrpSub),
                new SqlParameter("@Brand", Brand),
                new SqlParameter("@Season", Season),
                new SqlParameter("@Item_Id", Item_Id),
            };
            bool status = DBhelper.ExecuteNonQuery("Insert into [dbo].[Inserted_Data] (Category,Division,Type,Subcat,Artgrp,ArtgrpSub,Brand,Season,Item_Id) values (@Category,@Division,@Type,@Subcat,@Artgrp,@ArtgrpSub,@Brand,@Season,@Item_Id)", CommandType.Text, parameters);
            return status;
        }
    }


}
