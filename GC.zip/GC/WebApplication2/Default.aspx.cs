﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.DAL;

namespace WebApplication2
{
    public partial class _Default : Page
    {
        CommonBLL obj = new CommonBLL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                ddlbindCategory();



            }

        }

        public void ddlbindCategory()
        {
            try
            {
                DataTable dt = obj.getCategory();
                if (dt.Rows.Count > 0)
                {
                    BindingClass.BindDropDown(ddlCategory, dt, "Col-Category", "id", "Select Category");
                    BindingClass.ClearDropDown(ddlDivision, "Select Division");
                    BindingClass.ClearDropDown(ddlType, "Select Type");
                    BindingClass.ClearDropDown(ddlSubCategory, "Select Sub-Category");
                    BindingClass.ClearDropDown(ddlArticleGroup, "Select Article Group");
                    BindingClass.ClearDropDown(ddlArticleSGroup, "Select Article Sub-Group");
                    BindingClass.ClearDropDown(ddlBrand, "Select Brand");
                    BindingClass.ClearDropDown(ddlSeason, "Select Season");
                    ItemID.Text = "";
                }
                else
                { BindingClass.ClearDropDown(ddlCategory, "Select Category"); }
            }
            catch (Exception)
            {
                BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType());
            }
        }
        public void ddlbindDivision(int Id)
        {
            try
            {
                DataTable dt = obj.getDivision(Id);
                if (dt.Rows.Count > 0)
                {
                    BindingClass.BindDropDown(ddlDivision, dt, "ColDiv", "ColDivId", "Select Division");
                }
                else
                { BindingClass.ClearDropDown(ddlDivision, "Select Division"); }
            }
            catch (Exception)
            {
                BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType());
            }
        }
        public void ddlbindddlType(int Id, string columntype)
        {
            try
            {
                DataTable dt = obj.getType(Id, columntype);
                if (dt.Rows.Count > 0)
                {
                    BindingClass.BindDropDown(ddlType, dt, "TypeName", "TypeId", "Select Type");
                }
                else
                { BindingClass.ClearDropDown(ddlType, "Select Type"); }
            }
            catch (Exception)
            {
                BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType());
            }
        }
        public void ddlbindSubCategory(int Id)
        {
            try
            {
                DataTable dt = obj.getSubCategory(Id);
                if (dt.Rows.Count > 0)
                {
                    BindingClass.BindDropDown(ddlSubCategory, dt, "SubcatName", "ColSubcatId", "Select Sub-Category");
                }
                else
                { BindingClass.ClearDropDown(ddlSubCategory, "Select Sub-Category"); }
            }
            catch (Exception)
            {
                BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType());
            }
        }
        public void ddlbindArticleGroup(int Id)
        {
            try
            {
                DataTable dt = obj.getArcGroup(Id);
                if (dt.Rows.Count > 0)
                {
                    BindingClass.BindDropDown(ddlArticleGroup, dt, "ArtGrpName", "ArtGrpId", "Select Article Group");
                }
                else
                { BindingClass.ClearDropDown(ddlArticleGroup, "Select Article Group"); }
            }
            catch (Exception)
            {
                BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType());
            }
        }
        public void ddlbindArticle_sGroup(int Id, string columntype)
        {
            try
            {
                DataTable dt = obj.getArc_subGroup(Id, columntype);
                if (dt.Rows.Count > 0)
                {
                    BindingClass.BindDropDown(ddlArticleSGroup, dt, "ArtSubGrpName", "ArtSubGrpId", "Select Article Sub-Group");
                }
                else
                { BindingClass.ClearDropDown(ddlArticleSGroup, "Select Article Sub-Group"); }
            }
            catch (Exception)
            {
                BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType());
            }
        }
        public void ddlbindBrand(int Id)
        {
            try
            {
                DataTable dt = obj.getBrand(Id);
                if (dt.Rows.Count > 0)
                {
                    BindingClass.BindDropDown(ddlBrand, dt, "BrandName", "Brand_Id", "Select Brand");
                }
                else
                { BindingClass.ClearDropDown(ddlBrand, "Select Brand"); }
            }
            catch (Exception)
            {
                BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType());
            }
        }
        public void ddlbindSeason(int Id)
        {
            try
            {
                DataTable dt = obj.getSeason(Id);
                if (dt.Rows.Count > 0)
                {
                    BindingClass.BindDropDown(ddlSeason, dt, "SeasonName", "Season_Id", "Select Season");
                }
                else
                { BindingClass.ClearDropDown(ddlSeason, "Select Season"); }
            }
            catch (Exception)
            {
                BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType());
            }
        }

        protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlCategory.SelectedValue != "0")
                {
                    if (ddlCategory.SelectedValue == "1")
                    {
                        ddlbindDivision(Convert.ToInt32(ddlCategory.SelectedValue));
                        BindingClass.ClearDropDown(ddlType, "Select Type");
                        BindingClass.ClearDropDown(ddlSubCategory, "Select Sub-Category");
                        BindingClass.ClearDropDown(ddlArticleGroup, "Select Article Group");
                        BindingClass.ClearDropDown(ddlArticleSGroup, "Select Article Sub-Group");
                        BindingClass.ClearDropDown(ddlBrand, "Select Brand");
                        BindingClass.ClearDropDown(ddlSeason, "Select Season");
                        
                    }
                    if (ddlCategory.SelectedValue == "2")
                    {
                        ddlbindddlType(Convert.ToInt32(ddlCategory.SelectedValue), "id");
                        BindingClass.ClearDropDown(ddlSubCategory, "Select Sub-Category");
                        BindingClass.ClearDropDown(ddlArticleGroup, "Select Article Group");
                        BindingClass.ClearDropDown(ddlArticleSGroup, "Select Article Sub-Group");
                        BindingClass.ClearDropDown(ddlBrand, "Select Brand");
                        BindingClass.ClearDropDown(ddlSeason, "Select Season");
                    }
                    
                    
                }
                else
                {
                    ddlbindCategory();
                }
            }
            catch (Exception)
            { BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType()); }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (ItemID.Text != "")
                {
                    bool status = obj.postData(
                        ddlCategory.SelectedItem.Text,
                        ddlDivision.SelectedItem.Text,
                        ddlType.SelectedItem.Text,
                        ddlSubCategory.SelectedItem.Text,
                        ddlArticleGroup.SelectedItem.Text,
                        ddlArticleSGroup.SelectedItem.Text,
                        ddlBrand.SelectedItem.Text,
                        ddlSeason.SelectedItem.Text,
                        ItemID.Text
                        );
                    if (status == true)
                    {
                        ddlbindCategory();
                        BindingClass.AlertScriptManager(this.Page, this.GetType(), "toastr.success('Saved')");
                    }
                    else
                    {
                        BindingClass.AlertScriptManager(this.Page, this.GetType(), "toastr.error('Something went wrong, please check')");
                    }
                }else
                {
                    BindingClass.AlertScriptManager(this.Page, this.GetType(), "toastr.error('* Feilds must be filled')");
                }
            }
            catch (Exception ex)
            {
                BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType());
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                ddlbindCategory();
            }
            catch (Exception)
            {
                BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType());
            }
        }

        protected void ddlDivision_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlDivision.SelectedValue != "0")
                {
                    if (ddlCategory.SelectedValue == "1")
                    {
                        ddlbindddlType(Convert.ToInt32(ddlDivision.SelectedValue), "ColDivId");
                    }
                }
                else
                {
                    BindingClass.ClearDropDown(ddlType, "Select Type");
                    BindingClass.ClearDropDown(ddlSubCategory, "Select Sub-Category");
                    BindingClass.ClearDropDown(ddlArticleGroup, "Select Article Group");
                    BindingClass.ClearDropDown(ddlArticleSGroup, "Select Article Sub-Group");
                    BindingClass.ClearDropDown(ddlBrand, "Select Brand");
                    BindingClass.ClearDropDown(ddlSeason, "Select Season");
                }

            }
            catch (Exception)
            { BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType()); }
        }

        protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlType.SelectedValue != "0")
                {
                    ddlbindSubCategory(Convert.ToInt32(ddlType.SelectedValue));
                }
                else
                {
                    BindingClass.ClearDropDown(ddlSubCategory, "Select Sub-Category");
                    BindingClass.ClearDropDown(ddlArticleGroup, "Select Article Group");
                    BindingClass.ClearDropDown(ddlArticleSGroup, "Select Article Sub-Group");
                    BindingClass.ClearDropDown(ddlBrand, "Select Brand");
                    BindingClass.ClearDropDown(ddlSeason, "Select Season");
                }
            }
            catch (Exception)
            { BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType()); }
        }

        protected void ddlSubCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlSubCategory.SelectedValue != "0")
                {
                    ddlbindArticleGroup(Convert.ToInt32(ddlSubCategory.SelectedValue));
                }else
                {
                    BindingClass.ClearDropDown(ddlArticleGroup, "Select Article Group");
                    BindingClass.ClearDropDown(ddlArticleSGroup, "Select Article Sub-Group");
                    BindingClass.ClearDropDown(ddlBrand, "Select Brand");
                    BindingClass.ClearDropDown(ddlSeason, "Select Season");
                }
            }
            catch (Exception)
            { BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType()); }
        }

        protected void ddlArticleGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlArticleGroup.SelectedValue != "0")
                {
                    if (ddlCategory.SelectedValue == "1")
                    {
                        ddlbindArticle_sGroup(Convert.ToInt32(ddlArticleGroup.SelectedValue), "ArtGrpId");
                    }
                    if (ddlCategory.SelectedValue == "2")
                    {
                        ddlbindBrand(Convert.ToInt32(ddlArticleGroup.SelectedValue));
                    }
                }
                else
                { 
                    BindingClass.ClearDropDown(ddlArticleSGroup, "Select Article Sub-Group");
                    BindingClass.ClearDropDown(ddlBrand, "Select Brand");
                    BindingClass.ClearDropDown(ddlSeason, "Select Season");
                }
            }
            catch (Exception)
            { BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType()); }
        }

        protected void ddlArticleSGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlArticleSGroup.SelectedValue != "0")
                {
                    ddlbindBrand(Convert.ToInt32(ddlArticleSGroup.SelectedValue));
                }else
                {
                    BindingClass.ClearDropDown(ddlBrand, "Select Brand");
                    BindingClass.ClearDropDown(ddlSeason, "Select Season");
                }
            }
            catch (Exception)
            { BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType()); }
        }

        protected void ddlBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlBrand.SelectedValue != "0")
                {
                    if (ddlCategory.SelectedValue == "1")
                    {
                        ddlbindSeason(Convert.ToInt32(ddlBrand.SelectedValue));
                    }
                    if (ddlCategory.SelectedValue == "2")
                    {
                        ddlbindArticle_sGroup(Convert.ToInt32(ddlBrand.SelectedValue), "Brand_Id");
                    }
                }
                else
                {
                    BindingClass.ClearDropDown(ddlArticleSGroup, "Select Article Sub-Group");
                    BindingClass.ClearDropDown(ddlBrand, "Select Brand");
                    BindingClass.ClearDropDown(ddlSeason, "Select Season");
                }
            }
            catch (Exception)
            { BindingClass.ExceptionAlertScriptManager(this.Page, this.GetType()); }
        }
    }
}